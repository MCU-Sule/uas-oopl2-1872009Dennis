package com.example.squiddemo.controller;

public class SquidController {

}
