package com.example.squiddemo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class SquidApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(SquidApplication.class.getResource("SquidStage.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Squid Game Application!");
        stage.setScene(scene);
        stage.show();
        public void initialize(URL url, ResourceBundle rb) {
             = new();
             = new ();
             = FXCollections.observableArrayList();
            = FXCollections.observableArrayList();
    
            try {
                .addAll(l.fetchAllList());
            } catch (SQLException | ClassNotFoundException ex) {
                Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
    
            }
            .setItems(maintenanceList);
          .setItems(laboratoriList);
    
            col1.setCellValueFactory(data -> new SimpleObjectProperty(data.getValue().get()));
            col2.setCellValueFactory(data -> new SimpleObjectProperty(data.getValue().get()));
            col3.setCellValueFactory(data -> new SimpleObjectProperty(data.getValue().get()));
            col4.setCellValueFactory(data -> new SimpleObjectProperty(data.getValue().get()));
            col5.setCellValueFactory(data -> new SimpleObjectProperty(data.getValue().get()));
            
        }
    
        @FXML
        private void btnAddOnAction(ActionEvent event) {
            if (txtTask.getText().trim().isEmpty() || datePicker.getValue() == null || cmb.getSelectionModel().isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Data belum lengkap!!");
                alert.showAndWait();
            } else {
                Maintenance maintenance = new Maintenance();
                maintenance.set(this);
                maintenance.set(Date.valueOf(datePicker.getValue()));
                maintenance.set(cmb.getValue());
                maintenance.set(txt.getText());
                try {
                    int result = .addData(maintenance);
                    if (result == 1) {
                        .clear();
                        .clear();
                        .addAll(.fetchList(thisUser));
                    }
                } catch (ClassNotFoundException | SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    
        @FXML
        private void btnUpdateOnAction(ActionEvent event) {
            String id = txtId.getText();
            Laboratorium laboratorium = cmbLaboratorium.getValue();
            String task = txtTask.getText();
            Date date = Date.valueOf(datePicker.getValue());
    
            Maintenance maintenance = tableMain.getSelectionModel().getSelectedItem();
            int selected = tableMain.getSelectionModel().getSelectedIndex();
            Squid.setId(Integer.parseInt(id));
            Squid.setName(nama);
            Squid.setTask(task);
            Squis.setDate(date);
            try {
                int result = maintenanceDaoImpl.updateData(maintenance);
                if (result == 1) {
                    maintenanceList.remove(selected);
                    maintenanceList.clear();
                    maintenanceList.addAll(maintenanceDaoImpl.fetchList(thisUser));
                }
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
        }
    
        @FXML
        private void btnDeleteOnAction(ActionEvent event) {
    }

    public static void main(String[] args) {
        launch();
    }
}